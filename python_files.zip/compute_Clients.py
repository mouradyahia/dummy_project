# -*- coding: utf-8 -*-
import dataiku

from merge_informations_functions import add_country_and_concat

RENAME_COLUMNS = {
    "COUNTRY": "Country",
    "mois_stock": "mois stock",
    "NbClients": "Nb_Clients_Total",
    "NbClients_Registered": "Nb_Clients_Registered",
}
IBL_ORDER = {"BLS": "1", "ELS": "2", "TLS": "3", "OTHERS": "99"}

if __name__ == "__main__":
    df_uk_ecc = dataiku.Dataset("uk_client_ecc_aggregate").get_dataframe(infer_with_pandas=False)
    df_nl_ecc = dataiku.Dataset("nl_client_ecc_aggregate").get_dataframe(infer_with_pandas=False)
    df_it_ecc = dataiku.Dataset("it_client_ecc_aggregate").get_dataframe(infer_with_pandas=False)
    df_fr_ecc = dataiku.Dataset("fr_client_ecc_aggregate").get_dataframe(infer_with_pandas=False)
    df_es_ecc = dataiku.Dataset("es_client_ecc_aggregate").get_dataframe(infer_with_pandas=False)
    df_de_ecc = dataiku.Dataset("de_client_ecc_aggregate").get_dataframe(infer_with_pandas=False)
    df_be_ecc = dataiku.Dataset("be_client_ecc_aggregate").get_dataframe(infer_with_pandas=False)

    df_ecc = add_country_and_concat(
        df_es_ecc=df_es_ecc,
        df_uk_ecc=df_uk_ecc,
        df_it_ecc=df_it_ecc,
        df_nl_ecc=df_nl_ecc,
        df_be_ecc=df_be_ecc,
        df_fr_ecc=df_fr_ecc,
        df_de_ecc=df_de_ecc,
    )
    df_ecc = df_ecc.rename(columns=RENAME_COLUMNS)
    df_ecc["IBL"] = df_ecc["IBL"].replace(
        {"Not defined": "OTHERS", "NON CORE": "OTHERS"}
    )
    df_ecc["IBL_order"] = df_ecc["IBL"].map(IBL_ORDER)
    dataiku.Dataset("clients").write_with_schema(df_ecc)
