# -*- coding: utf-8 -*-
import dataiku

CHANNELS = ["FMD", "FMP", "SDS"]
DROP_COLUMNS = [
    "DCREDATE",
    "DCHANNEL_LABEL",
    "DSUBTYPE_DOC",
    "DENSEIGNE_NAME",
    "DORGANISME_CODE",
    "DCOMPANY_CODE",
    "DENSEIGNE_CODE",
]

if __name__ == "__main__":
    df_edm = dataiku.Dataset("all_countries_EDM").get_dataframe(infer_with_pandas=False)
    df_filtered = df_edm.loc[df_edm["DCHANNEL"].isin(CHANNELS)].copy()
    df_filtered["EDM_CREATION_DATE"] = (
        df_filtered["DCREDATE"].astype(str).str.split().str[0]
    )
    df_filtered = df_filtered.drop(columns=DROP_COLUMNS)

    for channel in CHANNELS:
        df_filtered[channel] = df_filtered["DCHANNEL"].eq(channel).astype(int)

    df_prepared = (
        df_filtered.groupby(["DCOUNTRY_CODE", "DCONTRACT_ID"], as_index=False)
        .agg({"EDM_CREATION_DATE": "max", "FMP": "max", "FMD": "max", "SDS": "max"})
        .rename(columns={"DCOUNTRY_CODE": "COUNTRY", "DCONTRACT_ID": "ID_CONTRAT"})
    )
    dataiku.Dataset("EDM_prepared").write_with_schema(df_prepared)
