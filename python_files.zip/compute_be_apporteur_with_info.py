# -*- coding: utf-8 -*-
import dataiku
from merge_informations_functions import merge_apporteur_info


if __name__ == "__main__":
    df_hierarchie_apporteur = dataiku.Dataset("be_hierarchie_apporteur").get_dataframe(infer_with_pandas=False)
    df_apporteur = dataiku.Dataset("be_apporteur").get_dataframe(infer_with_pandas=False)
    df_merged = merge_apporteur_info(df_apporteur, df_hierarchie_apporteur)
    dataiku.Dataset("be_apporteur_with_info").write_with_schema(df_merged)
