# -*- coding: utf-8 -*-
import dataiku
from dataset_preparation_functions import prepare_user_cols


if __name__ == "__main__":
    df_ecc = dataiku.Dataset("be_client_ecc").get_dataframe(infer_with_pandas=False)
    df_ecc_final = prepare_user_cols(df_ecc)
    dataiku.Dataset("be_client_ecc_prepared").write_with_schema(df_ecc_final)
