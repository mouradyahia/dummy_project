# -*- coding: utf-8 -*-
import dataiku
import pandas as pd

COUNTRY_CODES = {
    "FRA": "FR",
    "BEL": "BE",
    "DEU": "DE",
    "GBR": "UK",
    "ESP": "ES",
    "NLD": "NL",
    "ITA": "IT",
}

if __name__ == "__main__":
    df_ecc = dataiku.Dataset("Extract_espace_client").get_dataframe()
    df_ecc = df_ecc[["Country", "Third Party nb", "Creation date"]].copy()
    df_ecc["Creation date"] = pd.to_datetime(
        df_ecc["Creation date"],
        format="%m/%d/%y",
    )
    df_ecc = df_ecc.sort_values("Creation date").drop_duplicates(
        subset=["Country", "Third Party nb"],
        keep="first",
    )
    df_ecc["Country"] = df_ecc["Country"].replace(COUNTRY_CODES)

    dataiku.Dataset("be_espace_client_prepared").write_with_schema(
        df_ecc.loc[df_ecc["Country"].eq("BE")].copy()
    )
    dataiku.Dataset("es_espace_client_prepared").write_with_schema(
        df_ecc.loc[df_ecc["Country"].eq("ES")].copy()
    )
    dataiku.Dataset("uk_espace_client_prepared").write_with_schema(
        df_ecc.loc[df_ecc["Country"].eq("UK")].copy()
    )
    dataiku.Dataset("de_espace_client_prepared").write_with_schema(
        df_ecc.loc[df_ecc["Country"].eq("DE")].copy()
    )
    dataiku.Dataset("fr_espace_client_prepared").write_with_schema(
        df_ecc.loc[df_ecc["Country"].eq("FR")].copy()
    )
    dataiku.Dataset("it_espace_client_prepared").write_with_schema(
        df_ecc.loc[df_ecc["Country"].eq("IT")].copy()
    )
    dataiku.Dataset("nl_espace_client_prepared").write_with_schema(
        df_ecc.loc[df_ecc["Country"].eq("NL")].copy()
    )
