# -*- coding: utf-8 -*-
import dataiku

from merge_informations_functions import add_country_and_concat

if __name__ == "__main__":
    df_es_contract = dataiku.Dataset("es_contract_mel_with_informations").get_dataframe(infer_with_pandas=False)
    df_uk_contract = dataiku.Dataset("uk_contract_mel_with_informations").get_dataframe(infer_with_pandas=False)
    df_it_contract = dataiku.Dataset("it_contract_mel_with_informations").get_dataframe(infer_with_pandas=False)
    df_nl_contract = dataiku.Dataset("nl_contract_mel_with_informations").get_dataframe(infer_with_pandas=False)
    df_be_contract = dataiku.Dataset("be_contract_mel_with_informations").get_dataframe(infer_with_pandas=False)
    df_fr_contract = dataiku.Dataset("fr_contract_mel_with_informations").get_dataframe(infer_with_pandas=False)
    df_de_contract = dataiku.Dataset("de_contract_mel_with_informations").get_dataframe(infer_with_pandas=False)

    df_contrat = add_country_and_concat(
        df_es_contract=df_es_contract,
        df_uk_contract=df_uk_contract,
        df_it_contract=df_it_contract,
        df_nl_contract=df_nl_contract,
        df_be_contract=df_be_contract,
        df_fr_contract=df_fr_contract,
        df_de_contract=df_de_contract,
    )
    dataiku.Dataset("contract_mel_all_countries").write_with_schema(df_contrat)
