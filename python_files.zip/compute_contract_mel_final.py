# -*- coding: utf-8 -*-
import dataiku
import pandas as pd

CODE_LABEL_PAIRS = [
    ("CODE_ORGANISME", "LIB_ORGANISME"),
    ("CODE_PRODUIT_FINANCIER", "LIB_PRODUIT_FINANCIER"),
    ("CODE_PRODUIT_COMMERCIAL", "LIB_PRODUIT_COMMERCIAL"),
    ("CODE_MARCHE", "LIB_MARCHE"),
    ("CODE_SEG_MARCHE", "LIB_SEG_MARCHE"),
]
COUNTRY_ORDER = ["UK", "FR", "ES", "BE", "NL", "IT", "DE"]
IBL_ORDER = {"BLS": "1", "ELS": "2", "TLS": "3", "OTHERS": "99"}
MISSING_TEXT_PATTERN = r"(?i)^\s*(nan|nan \(nan\)|nan \(_\)|<na>)\s*$"

STRING_COLUMNS = [
    "COUNTRY",
    "ID_CONTRAT",
    "LIB_IBL",
    "CODE_ORGANISME",
    "LIB_ORGANISME",
    "CODE_ENSEIGNE",
    "CODE_SOCIETE",
    "CODE_PARTENAIRE",
    "LIB_PARTENAIRE",
    "CODE_PRODUIT_FINANCIER",
    "LIB_PRODUIT_FINANCIER",
    "CODE_PRODUIT_COMMERCIAL",
    "LIB_PRODUIT_COMMERCIAL",
    "CODE_MARCHE",
    "LIB_MARCHE",
    "CODE_SEG_MARCHE",
    "LIB_SEG_MARCHE",
    "ID_APPORTEUR",
    "LIB_APPORTEUR",
    "CODE_AGENCE_EQ_COMM",
    "LIB_AGENCE_EQ_COMM",
    "LIB_COMMERCIAL",
    "CODE_MODE_ACCES_APPLI",
    "CODE_ACCORD_AVIS",
    "InputMethod",
    "esignature_type",
]
INTEGER_COLUMNS = ["FMP", "FMD", "SDS", "so_easy", "payout"]

RENAME_COLUMNS = {
    "COUNTRY": "Country",
    "ID_CONTRAT": "Contract Id",
    "LIB_IBL": "IBL",
    "DATE_OPERATION_HISTO": "STL date",
    "CODE_ENSEIGNE": "Enseigne",
    "CODE_SOCIETE": "Societe",
    "CODE_COMMERCIAL": "Commercial",
    "CODE_MODE_ACCES_APPLI": "Access mode appli",
    "CODE_ACCORD_AVIS": "Code Accord",
    "InputMethod": "Input Method",
    "FMP": "FLG_FMP",
    "FMD": "FLG_FMD",
    "SDS": "FLG_SDS",
    "so_easy": "FLG_SoEasy",
    "payout": "FLG_Payout",
    "esignature_type": "Esignature Type",
    "CODE_PRODUIT_FINANCIER": "Financial Product Code",
}
DISPLAY_COLUMNS = {
    "Partner": ("LIB_PARTENAIRE", "CODE_PARTENAIRE"),
    "Market": ("LIB_MARCHE", "CODE_MARCHE"),
    "Apporteur": ("LIB_APPORTEUR", "ID_APPORTEUR"),
    "Agence": ("LIB_AGENCE_EQ_COMM", "CODE_AGENCE_EQ_COMM"),
    "Organisme": ("LIB_ORGANISME", "CODE_ORGANISME"),
    "Financial Product": ("LIB_PRODUIT_FINANCIER", "Financial Product Code"),
    "Commercial Product": ("LIB_PRODUIT_COMMERCIAL", "CODE_PRODUIT_COMMERCIAL"),
}
FINAL_COLUMNS = [
    "Country",
    "Contract Id",
    "IBL",
    "STL date",
    "Organisme",
    "Enseigne",
    "Societe",
    "Partner",
    "Financial Product",
    "Financial Product Code",
    "Commercial Product",
    "Market",
    "Apporteur",
    "Agence",
    "Commercial",
    "FLG_FMP",
    "FLG_FMD",
    "FLG_SDS",
    "FLG_SoEasy",
    "FLG_Payout",
    "Esignature Type",
]


def build_pivot_mapping(dataframe):
    pivots = []

    for code_column, label_column in CODE_LABEL_PAIRS:
        if code_column not in dataframe.columns or label_column not in dataframe.columns:
            continue

        temp = dataframe[[code_column, label_column, "COUNTRY"]].copy()
        temp = temp.rename(
            columns={code_column: "Code", label_column: "Label", "COUNTRY": "Country"}
        )
        temp["Variable"] = code_column[len("CODE_") :]
        pivot = temp.pivot_table(
            index=["Variable", "Code"],
            columns="Country",
            values="Label",
            aggfunc="first",
        ).reset_index()
        country_columns = [country for country in COUNTRY_ORDER if country in pivot.columns]
        pivots.append(
            pivot.reindex(columns=["Variable", "Code", *country_columns]).fillna("-")
        )

    return pd.concat(pivots, ignore_index=True)


if __name__ == "__main__":
    df_contrat = dataiku.Dataset("contract_mel_prepared").get_dataframe(infer_with_pandas=False)
    df_contrat = df_contrat.copy()

    for column in STRING_COLUMNS:
        df_contrat[column] = df_contrat[column].astype("str")

    df_contrat["DATE_OPERATION_HISTO"] = pd.to_datetime(
        df_contrat["DATE_OPERATION_HISTO"]
    ).dt.date
    df_contrat["CODE_COMMERCIAL"] = df_contrat["CODE_COMMERCIAL"].astype("Int64").astype("str")

    for column in INTEGER_COLUMNS:
        df_contrat[column] = df_contrat[column].astype("Int64")

    pivot_mapping = build_pivot_mapping(df_contrat)
    df_contrat = df_contrat.rename(columns=RENAME_COLUMNS)

    for output_column, (label_column, code_column) in DISPLAY_COLUMNS.items():
        df_contrat[output_column] = (
            df_contrat[label_column] + " (" + df_contrat[code_column].astype(str) + ")"
        )

    df_contrat = df_contrat.fillna("Not defined").replace(
        MISSING_TEXT_PATTERN,
        "Not defined",
        regex=True,
    )
    df_contrat["Commercial"] = df_contrat["Commercial"].replace(
        {"0": "Not defined", "<NA>": "Not defined"}
    )
    df_contrat = df_contrat[FINAL_COLUMNS].copy()
    df_contrat["IBL"] = df_contrat["IBL"].replace(
        {"Not defined": "OTHERS", "NON CORE": "OTHERS"}
    )
    df_contrat["IBL_order"] = df_contrat["IBL"].map(IBL_ORDER)

    dataiku.Dataset("contracts").write_with_schema(df_contrat)
    dataiku.Dataset("code_label_referential").write_with_schema(pivot_mapping)
