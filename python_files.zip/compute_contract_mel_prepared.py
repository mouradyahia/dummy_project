# -*- coding: utf-8 -*-
import dataiku
import pandas as pd

IBL_REPLACEMENTS = {
    "ELS VALUE CHAIN": "ELS",
    "ELS Value chain": "ELS",
    "TS": "TLS",
}
FLAG_COLUMNS = ["so_easy", "SDS", "FMD", "FMP"]


if __name__ == "__main__":
    df_contrat = dataiku.Dataset("contract_mel_all_countries").get_dataframe(infer_with_pandas=False)
    df_contrat = df_contrat.copy()
    df_payout = dataiku.Dataset("payout_case").get_dataframe(infer_with_pandas=False)
    df_edm = dataiku.Dataset("EDM_prepared").get_dataframe(infer_with_pandas=False)

    df_contrat["CODE_ACCORD_AVIS"] = df_contrat["CODE_ACCORD_AVIS"].fillna("N")
    df_contrat["contrat_substitution"] = (
        df_contrat["LOGIN_SUBTITUEUR"]
        .astype("string")
        .str[2]
        .eq("P")
        .fillna(False)
        .astype(int)
    )
    df_contrat["LIB_IBL"] = df_contrat["LIB_IBL"].replace(IBL_REPLACEMENTS)

    is_exu = df_contrat["CODE_OPERATION_COMMERCIALE"].eq("EXU")
    is_substitution = df_contrat["contrat_substitution"].eq(1)
    df_contrat["InputMethod"] = "Internal Entry"
    df_contrat.loc[is_exu & ~is_substitution, "InputMethod"] = "External Entry"
    df_contrat.loc[is_exu & is_substitution, "InputMethod"] = (
        "Internal Entry by Substitution"
    )

    df_contrat = df_contrat.merge(df_edm, how="left", on=["COUNTRY", "ID_CONTRAT"])
    df_contrat["so_easy"] = (
        df_contrat["FMD"].eq(1) | df_contrat["FMP"].eq(1)
    ).astype(int)

    payout_keys = pd.MultiIndex.from_frame(df_payout[["COUNTRY", "ID_CONTRAT"]])
    contrat_keys = pd.MultiIndex.from_frame(df_contrat[["COUNTRY", "ID_CONTRAT"]])
    df_contrat["payout"] = contrat_keys.isin(payout_keys).astype(int)

    df_contrat[FLAG_COLUMNS] = df_contrat[FLAG_COLUMNS].fillna(0)
    df_contrat["esignature_type"] = None

    is_manual = df_contrat["SDS"].eq(0)
    is_internal = ~is_manual & df_contrat["sub_esignature"].eq(1)
    is_dealer = ~is_manual & ~is_internal & df_contrat["SDS"].eq(1)

    df_contrat.loc[is_manual, "esignature_type"] = "Manual E-signature"
    df_contrat.loc[is_internal, "esignature_type"] = "Internal E-signature"
    df_contrat.loc[is_dealer, "esignature_type"] = "Dealer E-signature"

    dataiku.Dataset("contract_mel_prepared").write_with_schema(df_contrat)
