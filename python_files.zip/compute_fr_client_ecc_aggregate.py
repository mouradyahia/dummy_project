# -*- coding: utf-8 -*-
import dataiku
from dataset_preparation_functions import merge_and_clean_user


if __name__ == "__main__":
    df_ecc = dataiku.Dataset("fr_client_ecc_prepared").get_dataframe(infer_with_pandas=False)
    df_extract_ecc = dataiku.Dataset("fr_espace_client_prepared").get_dataframe(infer_with_pandas=False)

    df_ecc_final = merge_and_clean_user(df_ecc, df_extract_ecc)
    df_ecc_final = df_ecc_final.fillna("Not defined").replace(
        r"(?i)^\s*(nan|nan \(nan\)|nan \(_\)|<na>)\s*$",
        "Not defined",
        regex=True,
    )
    df_ecc_final["Commercial"] = df_ecc_final["Commercial"].replace(
        {"0": "Not Defined"}
    )
    dataiku.Dataset("fr_client_ecc_final").write_with_schema(df_ecc_final)
