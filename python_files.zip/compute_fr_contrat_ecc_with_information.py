# -*- coding: utf-8 -*-
import dataiku
from merge_informations_functions import merge_contract_ecc_info


if __name__ == "__main__":
    df_contrat_ecc = dataiku.Dataset("fr_contrat_for_ecc").get_dataframe(infer_with_pandas=False)
    df_marche = dataiku.Dataset("fr_contrat_marche").get_dataframe(infer_with_pandas=False)
    df_partenaire = dataiku.Dataset("fr_partenaire").get_dataframe(infer_with_pandas=False)
    df_produit_financier = dataiku.Dataset("fr_ref_produit_financier").get_dataframe(infer_with_pandas=False)
    df_produit_commercial = dataiku.Dataset("fr_ref_produit_commercial").get_dataframe(infer_with_pandas=False)
    df_apporteur = dataiku.Dataset("fr_apporteur_with_info").get_dataframe(infer_with_pandas=False)

    df_merged = merge_contract_ecc_info(
        df_contrat_ecc,
        df_produit_financier,
        df_produit_commercial,
        df_marche,
        df_partenaire,
        df_apporteur,
    )
    dataiku.Dataset("fr_contrat_ecc_with_information").write_with_schema(df_merged)
