# -*- coding: utf-8 -*-
import dataiku
from dataset_preparation_functions import prepare_user_stock


if __name__ == "__main__":
    df_contrat_ecc = dataiku.Dataset("it_contrat_ecc_with_information").get_dataframe(infer_with_pandas=False)
    df_stock = prepare_user_stock(df_contrat_ecc)
    dataiku.Dataset("it_client_ecc").write_with_schema(df_stock)
