# -*- coding: utf-8 -*-
import dataiku
from merge_informations_functions import merge_contract_MEL_info


if __name__ == "__main__":
    df_contrat_mel = dataiku.Dataset("it_contrat_mel").get_dataframe(infer_with_pandas=False)
    df_contrat = dataiku.Dataset("it_contrat").get_dataframe(infer_with_pandas=False)
    df_produit_financier = dataiku.Dataset("it_ref_produit_financier").get_dataframe(infer_with_pandas=False)
    df_produit_commercial = dataiku.Dataset("it_ref_produit_commercial").get_dataframe(infer_with_pandas=False)
    df_marche = dataiku.Dataset("it_contrat_marche").get_dataframe(infer_with_pandas=False)
    df_partenaire = dataiku.Dataset("it_partenaire").get_dataframe(infer_with_pandas=False)
    df_apporteur = dataiku.Dataset("it_apporteur_with_info").get_dataframe(infer_with_pandas=False)
    df_request = dataiku.Dataset("it_request_for_contrat_MEL").get_dataframe(infer_with_pandas=False)
    df_avis = dataiku.Dataset("it_avis_sead").get_dataframe(infer_with_pandas=False)
    df_esignature = dataiku.Dataset("it_esignature_with_sub").get_dataframe(infer_with_pandas=False)

    df_merged = merge_contract_MEL_info(
        df_contrat_mel,
        df_contrat,
        df_produit_financier,
        df_produit_commercial,
        df_marche,
        df_partenaire,
        df_apporteur,
        df_request,
        df_avis,
        df_esignature,
    )
    dataiku.Dataset("it_contract_mel_with_informations").write_with_schema(df_merged)
