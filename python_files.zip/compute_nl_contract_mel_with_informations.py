# -*- coding: utf-8 -*-
import dataiku
from merge_informations_functions import merge_contract_MEL_info


if __name__ == "__main__":
    df_contrat_mel = dataiku.Dataset("nl_contrat_mel").get_dataframe(infer_with_pandas=False)
    df_contrat = dataiku.Dataset("nl_contrat").get_dataframe(infer_with_pandas=False)
    df_produit_financier = dataiku.Dataset("nl_ref_produit_financier").get_dataframe(infer_with_pandas=False)
    df_produit_commercial = dataiku.Dataset("nl_ref_produit_commercial").get_dataframe(infer_with_pandas=False)
    df_marche = dataiku.Dataset("nl_contrat_marche").get_dataframe(infer_with_pandas=False)
    df_partenaire = dataiku.Dataset("nl_partenaire").get_dataframe(infer_with_pandas=False)
    df_apporteur = dataiku.Dataset("nl_apporteur_with_info").get_dataframe(infer_with_pandas=False)
    df_request = dataiku.Dataset("nl_request_for_contrat_MEL").get_dataframe(infer_with_pandas=False)
    df_avis = dataiku.Dataset("nl_avis_sead").get_dataframe(infer_with_pandas=False)
    df_esignature = dataiku.Dataset("nl_esignature_with_sub").get_dataframe(infer_with_pandas=False)

    df_merged = merge_contract_MEL_info(
        df_contrat_mel,
        df_contrat,
        df_produit_financier,
        df_produit_commercial,
        df_marche,
        df_partenaire,
        df_apporteur,
        df_request,
        df_avis,
        df_esignature,
    )
    dataiku.Dataset("nl_contract_mel_with_informations").write_with_schema(df_merged)
