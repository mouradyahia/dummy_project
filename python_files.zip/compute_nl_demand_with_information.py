# -*- coding: utf-8 -*-
import dataiku
from merge_informations_functions import merge_demand_info


if __name__ == "__main__":
    df_marche = dataiku.Dataset("nl_request_marche").get_dataframe(infer_with_pandas=False)
    df_request = dataiku.Dataset("nl_request_information").get_dataframe(infer_with_pandas=False)
    df_produit_financier = dataiku.Dataset("nl_ref_produit_financier").get_dataframe(infer_with_pandas=False)
    df_produit_commercial = dataiku.Dataset("nl_ref_produit_commercial").get_dataframe(infer_with_pandas=False)
    df_apporteur = dataiku.Dataset("nl_apporteur_with_info").get_dataframe(infer_with_pandas=False)
    df_partenaire = dataiku.Dataset("nl_partenaire_demand").get_dataframe(infer_with_pandas=False)
    df_avis = dataiku.Dataset("nl_avis_sead").get_dataframe(infer_with_pandas=False)

    df_merged = merge_demand_info(
        df_request,
        df_avis,
        df_produit_financier,
        df_produit_commercial,
        df_marche,
        df_partenaire,
        df_apporteur,
    )
    dataiku.Dataset("nl_demand_with_information").write_with_schema(df_merged)
