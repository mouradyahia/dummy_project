# -*- coding: utf-8 -*-
import dataiku

COUNTRY_CODES = {
    "ESP": "ES",
    "BEL": "BE",
    "FRA": "FR",
    "NLD": "NL",
    "DEU": "DE",
    "GBR": "UK",
}
CONTRACT_COLUMNS = ["N° du Contrat", "NÂ° du Contrat"]
REQUEST_COLUMNS = ["N° de la demande", "NÂ° de la demande"]


def first_existing_column(dataframe, candidates):
    for column in candidates:
        if column in dataframe.columns:
            return column
    raise KeyError(f"Missing expected column. Tried: {candidates}")


if __name__ == "__main__":
    df_bpm = dataiku.Dataset("all_countries_BPM").get_dataframe(infer_with_pandas=False)
    df_bpm = df_bpm.copy()
    contract_column = first_existing_column(df_bpm, CONTRACT_COLUMNS)
    request_column = first_existing_column(df_bpm, REQUEST_COLUMNS)

    df_bpm["ID_CONTRAT"] = df_bpm[contract_column].fillna(df_bpm[request_column])
    df_payout = df_bpm[["Pays", "ID_CONTRAT"]].drop_duplicates().copy()
    df_payout["Pays"] = df_payout["Pays"].replace(COUNTRY_CODES)
    df_payout = df_payout.rename(columns={"Pays": "COUNTRY"})

    dataiku.Dataset("payout_case").write_with_schema(df_payout)
