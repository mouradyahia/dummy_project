# -*- coding: utf-8 -*-
import dataiku

from merge_informations_functions import add_country_and_concat

if __name__ == "__main__":
    df_be_request = dataiku.Dataset("be_demand_with_information").get_dataframe(infer_with_pandas=False)
    df_it_request = dataiku.Dataset("it_demand_with_information").get_dataframe(infer_with_pandas=False)
    df_uk_request = dataiku.Dataset("uk_demand_with_information").get_dataframe(infer_with_pandas=False)
    df_de_request = dataiku.Dataset("de_demand_with_information").get_dataframe(infer_with_pandas=False)
    df_nl_request = dataiku.Dataset("nl_demand_with_information").get_dataframe(infer_with_pandas=False)
    df_es_request = dataiku.Dataset("es_demand_with_information").get_dataframe(infer_with_pandas=False)
    df_fr_request = dataiku.Dataset("fr_demand_with_information").get_dataframe(infer_with_pandas=False)

    df_request = add_country_and_concat(
        df_es_request=df_es_request,
        df_uk_request=df_uk_request,
        df_it_request=df_it_request,
        df_nl_request=df_nl_request,
        df_be_request=df_be_request,
        df_fr_request=df_fr_request,
        df_de_request=df_de_request,
    )
    dataiku.Dataset("request_all_countries").write_with_schema(df_request)
