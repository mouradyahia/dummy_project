# -*- coding: utf-8 -*-
import dataiku
import pandas as pd

CODE_LABEL_PAIRS = [
    ("CODE_ORGANISME", "LIB_ORGANISME"),
    ("CODE_PRODUIT_FINANCIER", "LIB_PRODUIT_FINANCIER"),
    ("CODE_PRODUIT_COMMERCIAL", "LIB_PRODUIT_COMMERCIAL"),
    ("CODE_MARCHE", "LIB_MARCHE"),
    ("CODE_SEG_MARCHE", "LIB_SEG_MARCHE"),
]
COUNTRY_ORDER = ["UK", "FR", "ES", "BE", "NL", "IT", "DE"]
IBL_ORDER = {"BLS": "1", "ELS": "2", "TLS": "3", "OTHERS": "99"}
MISSING_TEXT_PATTERN = r"(?i)^\s*(nan|nan \(nan\)|nan \(_\)|<na>)\s*$"

STRING_COLUMNS = [
    "COUNTRY",
    "ID_DEMAND",
    "LIB_IBL",
    "CODE_ORGANISME",
    "LIB_ORGANISME",
    "CODE_ENSEIGNE",
    "CODE_SOCIETE",
    "CODE_PARTENAIRE",
    "LIB_PARTENAIRE",
    "CODE_PRODUIT_FINANCIER",
    "LIB_PRODUIT_FINANCIER",
    "CODE_PRODUIT_COMMERCIAL",
    "LIB_PRODUIT_COMMERCIAL",
    "CODE_MARCHE",
    "LIB_MARCHE",
    "CODE_SEG_MARCHE",
    "LIB_SEG_MARCHE",
    "ID_APPORTEUR",
    "LIB_APPORTEUR",
    "CODE_AGENCE_EQ_COMM",
    "LIB_AGENCE_EQ_COMM",
    "LIB_COMMERCIAL",
    "CODE_MODE_ACCESS_APPLI",
    "CODE_ACCORD_AVIS",
    "InputMethod",
    "Categorie Request",
]
RENAME_COLUMNS = {
    "COUNTRY": "Country",
    "ID_DEMAND": "Request Id",
    "CODE_STATUS": "Status",
    "LIB_IBL": "IBL",
    "DATE_CREATION_DEMAND": "Request Creation Date",
    "CODE_ENSEIGNE": "Enseigne",
    "CODE_SOCIETE": "Societe",
    "CODE_COMMERCIAL": "Commercial",
    "CODE_MODE_ACCESS_APPLI": "Access mode appli",
    "CODE_ACCORD_AVIS": "Code Accord",
    "InputMethod": "Input Method",
}
DISPLAY_COLUMNS = {
    "Partner": ("LIB_PARTENAIRE", "CODE_PARTENAIRE"),
    "Market": ("LIB_MARCHE", "CODE_MARCHE"),
    "Apporteur": ("LIB_APPORTEUR", "ID_APPORTEUR"),
    "Agence": ("LIB_AGENCE_EQ_COMM", "CODE_AGENCE_EQ_COMM"),
    "Organisme": ("LIB_ORGANISME", "CODE_ORGANISME"),
    "Financial Product": ("LIB_PRODUIT_FINANCIER", "CODE_PRODUIT_FINANCIER"),
    "Commercial Product": ("LIB_PRODUIT_COMMERCIAL", "CODE_PRODUIT_COMMERCIAL"),
}
FINAL_COLUMNS = [
    "Country",
    "Request Id",
    "Status",
    "IBL",
    "Request Creation Date",
    "Organisme",
    "Enseigne",
    "Partner",
    "Financial Product",
    "Commercial Product",
    "Market",
    "Apporteur",
    "Agence",
    "Commercial",
    "Categorie Request",
]


def build_pivot_mapping(dataframe):
    pivots = []

    for code_column, label_column in CODE_LABEL_PAIRS:
        if code_column not in dataframe.columns or label_column not in dataframe.columns:
            continue

        temp = dataframe[[code_column, label_column, "COUNTRY"]].copy()
        temp = temp.rename(
            columns={code_column: "Code", label_column: "Label", "COUNTRY": "Country"}
        )
        temp["Variable"] = code_column[len("CODE_") :]
        pivot = temp.pivot_table(
            index=["Variable", "Code"],
            columns="Country",
            values="Label",
            aggfunc="first",
        ).reset_index()
        country_columns = [country for country in COUNTRY_ORDER if country in pivot.columns]
        pivots.append(
            pivot.reindex(columns=["Variable", "Code", *country_columns]).fillna("-")
        )

    return pd.concat(pivots, ignore_index=True)


if __name__ == "__main__":
    df_request = dataiku.Dataset("request_prepared").get_dataframe(infer_with_pandas=False)
    df_request = df_request.copy()

    for column in STRING_COLUMNS:
        df_request[column] = df_request[column].astype("str")

    df_request["DATE_CREATION_DEMAND"] = pd.to_datetime(
        df_request["DATE_CREATION_DEMAND"]
    ).dt.date
    df_request["CODE_COMMERCIAL"] = df_request["CODE_COMMERCIAL"].astype("Int64").astype("str")

    pivot_mapping = build_pivot_mapping(df_request)
    df_request = df_request.rename(columns=RENAME_COLUMNS)

    for output_column, (label_column, code_column) in DISPLAY_COLUMNS.items():
        df_request[output_column] = (
            df_request[label_column] + " (" + df_request[code_column].astype(str) + ")"
        )

    df_request = df_request.fillna("Not defined").replace(
        MISSING_TEXT_PATTERN,
        "Not defined",
        regex=True,
    )
    df_request["Commercial"] = df_request["Commercial"].replace(
        {"0": "Not defined", "<NA>": "Not defined"}
    )
    df_request = df_request[FINAL_COLUMNS].copy()
    df_request["IBL"] = df_request["IBL"].replace(
        {"Not defined": "OTHERS", "NON CORE": "OTHERS"}
    )
    df_request["IBL_order"] = df_request["IBL"].map(IBL_ORDER)

    dataiku.Dataset("requests").write_with_schema(df_request)
    dataiku.Dataset("code_label_referential_demand").write_with_schema(pivot_mapping)
