# -*- coding: utf-8 -*-
import dataiku

IBL_REPLACEMENTS = {
    "ELS VALUE CHAIN": "ELS",
    "ELS Value chain": "ELS",
    "TS": "TLS",
}


if __name__ == "__main__":
    df_request = dataiku.Dataset("request_all_countries").get_dataframe(infer_with_pandas=False)
    df_request = df_request.copy()
    df_tool_front = dataiku.Dataset("X_Tool_Front").get_dataframe(infer_with_pandas=False)
    df_access_mode = dataiku.Dataset("X_Access_Mode_Front").get_dataframe(infer_with_pandas=False)

    df_request["CODE_ACCORD_AVIS"] = df_request["CODE_ACCORD_AVIS"].fillna("N")
    df_request["request_substitution"] = (
        df_request["LOGIN_SUBTITUEUR"]
        .astype("string")
        .str[2]
        .eq("P")
        .fillna(False)
        .astype(int)
    )
    df_request["LIB_IBL"] = df_request["LIB_IBL"].replace(IBL_REPLACEMENTS)

    is_exu = df_request["CODE_OPERATION_COMMERCIALE"].eq("EXU")
    is_substitution = df_request["request_substitution"].eq(1)
    df_request["InputMethod"] = "SDO Entry"
    df_request.loc[is_exu & ~is_substitution, "InputMethod"] = "Dealer Entry"
    df_request.loc[is_exu & is_substitution, "InputMethod"] = "Internal Entry"

    df_request = df_request.merge(
        df_tool_front,
        how="left",
        left_on="CODE_TYPE_APPLI",
        right_on="Code",
    )
    df_request = df_request.merge(
        df_access_mode,
        how="left",
        left_on="CODE_MODE_ACCESS_APPLI",
        right_on="Code",
    )
    df_request["Categorie Request"] = (
        df_request["Tool"]
        + " - "
        + df_request["Channel"]
        + " - "
        + df_request["InputMethod"]
    )
    df_request = df_request.loc[df_request["CODE_PRODUIT_FINANCIER"].ne("123")].copy()
    df_request = df_request.loc[df_request["LIB_MARCHE"].ne("TS-DIRECT")].copy()

    dataiku.Dataset("request_prepared").write_with_schema(df_request)
