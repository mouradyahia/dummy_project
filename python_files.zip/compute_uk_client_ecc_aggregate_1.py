# -*- coding: utf-8 -*-
import dataiku
from dataset_preparation_functions import aggregate_user_stats


if __name__ == "__main__":
    df_ecc = dataiku.Dataset("uk_client_ecc_final").get_dataframe(infer_with_pandas=False)
    df_client_agg = aggregate_user_stats(df_ecc)
    dataiku.Dataset("uk_client_ecc_aggregate").write_with_schema(df_client_agg)
