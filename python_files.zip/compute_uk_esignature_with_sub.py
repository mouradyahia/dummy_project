# -*- coding: utf-8 -*-
import dataiku
from dataset_preparation_functions import prepare_esignature


if __name__ == "__main__":
    df_esignature = dataiku.Dataset("uk_esignature").get_dataframe(infer_with_pandas=False)
    df_esignature_with_sub = prepare_esignature(df_esignature)
    dataiku.Dataset("uk_esignature_with_sub").write_with_schema(df_esignature_with_sub)
